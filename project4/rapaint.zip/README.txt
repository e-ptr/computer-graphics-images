Ryan Painter rapaint@clemson.edu

convolve:

	This program convolves images with provided filters

	1) run the "make" command
	2) run "./convolve <filter file> <image to open> <optional name for saved image>"
	
	Issues:
	sobol-vert produces an inverted result from the provided examples. The kernel is flipped properly and sobol-horiz results are as expected.
